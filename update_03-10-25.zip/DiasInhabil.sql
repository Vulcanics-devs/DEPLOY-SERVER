-- Semana Santa (15-30 de abril)
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-16', '2026-04-16', 2026, 4, 16, 2026, 4, 16, 'Semana santa', 2, '2026-04-16');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-17', '2026-04-17', 2026, 4, 17, 2026, 4, 17, 'Semana santa', 2, '2026-04-17');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-20', '2026-04-20', 2026, 4, 20, 2026, 4, 20, 'Semana santa', 2, '2026-04-20');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-19', '2026-04-19', 2026, 4, 19, 2026, 4, 19, 'Semana santa', 2, '2026-04-19');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-18', '2026-04-18', 2026, 4, 18, 2026, 4, 18, 'Semana santa', 2, '2026-04-18');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-15', '2026-04-15', 2026, 4, 15, 2026, 4, 15, 'Semana santa', 2, '2026-04-15');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-21', '2026-04-21', 2026, 4, 21, 2026, 4, 21, 'Semana santa', 2, '2026-04-21');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-22', '2026-04-22', 2026, 4, 22, 2026, 4, 22, 'Semana santa', 2, '2026-04-22');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-23', '2026-04-23', 2026, 4, 23, 2026, 4, 23, 'Semana santa', 2, '2026-04-23');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-24', '2026-04-24', 2026, 4, 24, 2026, 4, 24, 'Semana santa', 2, '2026-04-24');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-25', '2026-04-25', 2026, 4, 25, 2026, 4, 25, 'Semana santa', 2, '2026-04-25');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-26', '2026-04-26', 2026, 4, 26, 2026, 4, 26, 'Semana santa', 2, '2026-04-26');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-27', '2026-04-27', 2026, 4, 27, 2026, 4, 27, 'Semana santa', 2, '2026-04-27');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-28', '2026-04-28', 2026, 4, 28, 2026, 4, 28, 'Semana santa', 2, '2026-04-28');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-29', '2026-04-29', 2026, 4, 29, 2026, 4, 29, 'Semana santa', 2, '2026-04-29');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-30', '2026-04-30', 2026, 4, 30, 2026, 4, 30, 'Semana santa', 2, '2026-04-30');

-- Días festivos oficiales
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-01-01', '2026-01-01', 2026, 1, 1, 2026, 1, 1, 'Año Nuevo', 1, '2026-01-01');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-02-02', '2026-02-02', 2026, 2, 2, 2026, 2, 2, 'Día de la Constitución', 1, '2026-02-02');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-03-16', '2026-03-16', 2026, 3, 16, 2026, 3, 16, 'Natalicio B. Ju�rez', 1, '2026-03-16');

-- Semana Santa (finales de marzo - principios de abril)
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-03-31', '2026-03-31', 2026, 3, 31, 2026, 3, 31, 'Semana Santa', 2, '2026-03-31');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-03-30', '2026-03-30', 2026, 3, 30, 2026, 3, 30, 'Semana Santa', 2, '2026-03-30');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-02', '2026-04-02', 2026, 4, 2, 2026, 4, 2, 'Semana Santa', 2, '2026-04-02');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-04', '2026-04-04', 2026, 4, 4, 2026, 4, 4, 'Semana Santa', 2, '2026-04-04');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-03', '2026-04-03', 2026, 4, 3, 2026, 4, 3, 'Semana Santa', 2, '2026-04-03');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-04-01', '2026-04-01', 2026, 4, 1, 2026, 4, 1, 'Semana Santa', 2, '2026-04-01');

-- Mayo
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-05-01', '2026-05-01', 2026, 5, 1, 2026, 5, 1, 'Día del Trabajo', 1, '2026-05-01');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-05-10', '2026-05-10', 2026, 5, 10, 2026, 5, 10, 'Día de las Madres', 2, '2026-05-10');

-- Septiembre
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-09-16', '2026-09-16', 2026, 9, 16, 2026, 9, 16, 'Independencia de México', 1, '2026-09-16');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-09-15', '2026-09-15', 2026, 9, 15, 2026, 9, 15, 'Independencia de México', 1, '2026-09-15');

-- Noviembre
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-11-02', '2026-11-02', 2026, 11, 2, 2026, 11, 2, 'Día de Muertos', 2, '2026-11-02');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-11-16', '2026-11-16', 2026, 11, 16, 2026, 11, 16, 'Revolución Mexicana', 1, '2026-11-16');

-- Diciembre
INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-12', '2026-12-12', 2026, 12, 12, 2026, 12, 12, 'Día de la Virgen', 2, '2026-12-12');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-23', '2026-12-23', 2026, 12, 23, 2026, 12, 23, 'Paro Producción Diciembre', 2, '2026-12-23');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-24', '2026-12-24', 2026, 12, 24, 2026, 12, 24, 'Paro Producción Diciembre', 2, '2026-12-24');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-25', '2026-12-25', 2026, 12, 25, 2026, 12, 25, 'Paro Producción Diciembre', 2, '2026-12-25');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-26', '2026-12-26', 2026, 12, 26, 2026, 12, 26, 'Paro Producción Diciembre', 2, '2026-12-26');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-28', '2026-12-28', 2026, 12, 28, 2026, 12, 28, 'Paro Producción Diciembre', 2, '2026-12-28');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-27', '2026-12-27', 2026, 12, 27, 2026, 12, 27, 'Paro Producción Diciembre', 2, '2026-12-27');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-29', '2026-12-29', 2026, 12, 29, 2026, 12, 29, 'Paro Producción Diciembre', 2, '2026-12-29');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-30', '2026-12-30', 2026, 12, 30, 2026, 12, 30, 'Paro Producción Diciembre', 2, '2026-12-30');

INSERT INTO [dbo].[DiasInhabiles] (FechaInicial, FechaFinal, AnioFechaInicial, MesFechaInicial, DiaFechaInicial, AnioFechaFinal, MesFechaFinal, DiaFechaFinal, Detalles, TipoActividadDelDia, Fecha)
VALUES ('2026-12-31', '2026-12-31', 2026, 12, 31, 2026, 12, 31, 'Paro Producción Diciembre', 2, '2026-12-31');