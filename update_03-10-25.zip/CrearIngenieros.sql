-- Nancy Verónica García Ziga
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Nancy Verónica García Ziga', 'nancy03.garcia@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (5, SCOPE_IDENTITY());

-- Saul Alberto Azuara Larraga
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Saul Alberto Azuara Larraga', 'saul.alberto.azuara.larraga@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (5, SCOPE_IDENTITY());

-- Carlos Dívila Martínez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Carlos Dívila Martínez', 'carlos.2.davila.martinez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (5, SCOPE_IDENTITY());

-- Karla Monserrat Leyva Esparza
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Karla Monserrat Leyva Esparza', 'karla.leyva.esparza@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (5, SCOPE_IDENTITY());

-- Jose Guerrero Hernandez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jose Guerrero Hernandez', 'Jose.Guerrero@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (5, SCOPE_IDENTITY());