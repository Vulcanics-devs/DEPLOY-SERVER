-- Emanuel Morales de la Rosa
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Emanuel Morales de la Rosa', 'emmanuel.2.morales.de.la.rosa@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Maricela Hernandez Sandoval
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Maricela Hernandez Sandoval', 'marisela.hernandez.sandoval@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Yazmin Velazquez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Yazmin Velazquez', 'yazmin.velazquez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Diego Jonathan Garcia Aleman
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Diego Jonathan Garcia Aleman', 'diego.garcia.aleman@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Imelda Sanchez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Imelda Sanchez', 'Imelda.Sanchez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Hugo Perez Luvanos
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Hugo Perez Luvanos', 'hugo.perez.luevanos@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Marco Hernandez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Marco Hernandez', 'marco.hernandez.cervantes@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Romualdo Granados
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Romualdo Granados', 'romualdo.granados.monreal@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Elodia Guadalupe Hernandez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Elodia Guadalupe Hernandez', 'elodia.guadalupe.hernandez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Carlos Martinez Tovar
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Carlos Martinez Tovar', 'carlos.4.martinez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Alfonso Loredo Martinez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Alfonso Loredo Martinez', 'alfonso.loredo@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Oscar Guevara
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Oscar Guevara', 'oscar.2.guevara@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Roberto Castillo Estrada
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Roberto Castillo Estrada', 'roberto.castillo@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Ricardo Fernandez Ponce
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Ricardo Fernandez Ponce', 'ricardo.2.fernandez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Jose Alfredo Martinez Noyola
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jose Alfredo Martinez Noyola', 'alfredo.martinez-noyola@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Juan Nieto Orta
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Juan Nieto Orta', 'juan.2.nieto@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Osvaldo Elias Zapata
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Osvaldo Elias Zapata', 'osvaldo.elias@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Jose Luis Navarro Hernandez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jose Luis Navarro Hernandez', 'joseluis.navarro@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Angel Urso Gonzalez Mendoza
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Angel Urso Gonzalez Mendoza', 'angel.urso@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Javier Galarza Viana
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Javier Galarza Viana', 'javier.galarza@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Miguel Angel Martinez Tellez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Miguel Angel Martinez Tellez', 'miguel02.martinez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Miguel Angel Rivera Lopez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Miguel Angel Rivera Lopez', 'miguel.rivera@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Israel Hernandez Perez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Israel Hernandez Perez', 'israel.hernandez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Jose Luis Calvillo Sanchez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jose Luis Calvillo Sanchez', 'jose.calvillo@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Alvarez Romero Albino Marcos
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Alvarez Romero Albino Marcos', 'marcos.alvarez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Hernandez Torres Adrian
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Hernandez Torres Adrian', 'Adrian02.Hernandez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Juache Sanjuanero Arturo
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Juache Sanjuanero Arturo', 'arturo.juache.sanjuanero@conti.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Macias Salazar Jose Antonio
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Macias Salazar Jose Antonio', 'antonio01.macias@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Isaac Martinez Melos
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Isaac Martinez Melos', 'isaac.martinez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Miguel Avalos
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Miguel Avalos', 'miguel.avalos@conti.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Diego Acevedo Orta
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Diego Acevedo Orta', 'diego02.acevedo.orta@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Oscar Daniel Pineda Delgado
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Oscar Daniel Pineda Delgado', 'oscar.pineda.delgado@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Omar Loredo
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Omar Loredo', 'omar.lerodo@conti.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Cesar Paul Jara Ortiz
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Cesar Paul Jara Ortiz', 'cesar.jara@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Gerardo Esparza
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Gerardo Esparza', 'gerardo.esparza@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Sergio Antonio Martinez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Sergio Antonio Martinez', 'sergio.antonio.martinez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Joshua Adrian Martinez Almazan
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Joshua Adrian Martinez Almazan', 'joshua.martinez.almazan@continental.com', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Emma Salazar Sanchez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Emma Salazar Sanchez', 'Emma.Salazar@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Pedro Luis Mendoza
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Pedro Luis Mendoza', 'Pedro1.Mendoza@continental.com', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Juana Edith Sanchez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Juana Edith Sanchez', 'Juana.Sanchez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Monica Gutierrez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Monica Gutierrez', 'monica.gutierrez.castillo@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Edgar Filemon Cerda Gonzalez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Edgar Filemon Cerda Gonzalez', 'edgar.filemon.cerda.gonzalez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Moises Govea
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Moises Govea', 'moises.govea.medina@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Luis Miguel Martinez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Luis Miguel Martinez', 'luis.miguel.martinez.cardona@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Gabriel Ruiz
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Gabriel Ruiz', 'gabriel.ruiz.sanchez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Israel Diaz
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Israel Diaz', 'israel.diaz.pardo@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Arturo Rodriguez Sustaita
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Arturo Rodriguez Sustaita', 'arturo.rodriguez.sustaita@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Norberto Gomez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Norberto Gomez', 'norberto.gomez.hernandez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Luis Adrian Avila
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Luis Adrian Avila', 'luis.adrian.avila.ramirez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Luis Garcia
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Luis Garcia', 'luis.angel.garcia@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Jaime Silva
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jaime Silva', 'jaime.silva.ramirez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Edgardo Paz
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Edgardo Paz', 'Edgardo.Paz@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Martin de Jesus Sanchez Garcia
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Martin de Jesus Sanchez Garcia', 'martin.de.jesus.sanchez.garcia@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Domingo Coronado
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Domingo Coronado', 'Domingo.Coronado@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Guillermo Emmanuel Chavarria Torres
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Guillermo Emmanuel Chavarria Torres', 'guillermo.emmanuel.chavarria.torres@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Fernando Dueñas
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Fernando Dueñas', 'Fernando.Duenas@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Jaime Camacho Chavarria
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jaime Camacho Chavarria', 'jaime.camacho.chavarria@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Alejandra Lizeth Alfaro Saldana
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Alejandra Lizeth Alfaro Saldana', 'lizet.alejandra.alfaro.saldana@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Juan Manuel Hidalgo Monsivais
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Juan Manuel Hidalgo Monsivais', 'juan.manuel.hidalgo.monsivais@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Oscar Reyna
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Oscar Reyna', 'Oscar.Reyna@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Zulema Ramirez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Zulema Ramirez', 'zulema.ramirez.guevara@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());

-- Jesus Emanuel Vazquez Fonseca
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jesus Emanuel Vazquez Fonseca', 'jesus.emanuel.vazquez.fonseca@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (4, SCOPE_IDENTITY());
