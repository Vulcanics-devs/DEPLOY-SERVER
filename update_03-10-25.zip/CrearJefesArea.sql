-- Carolina Cortez Galaviz
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Carolina Cortez Galaviz', 'carolina.cortez.galaviz@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Arcelia Martinez Villalobos
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Arcelia Martinez Villalobos', 'arcelia.martinez.villalobos@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Hugo Borges
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Hugo Borges', 'hugo.borges@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Jose Enrique Flores Ramirez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jose Enrique Flores Ramirez', 'enrique.flores@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Maricela Malpica Godinez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Maricela Malpica Godinez', 'maricela.malpica@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Gustavo Guevara Medina
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Gustavo Guevara Medina', 'gustavo.guevara@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Ricardo Bravo Vazquez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Ricardo Bravo Vazquez', 'ricardo.bravo@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Elena Rosas
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Elena Rosas', 'Elena.Rosas@continental.com', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Hugo Cesar de la Torre Mercado
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Hugo Cesar de la Torre Mercado', 'Hugo.DelaTorre@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Jesus Daniel Vazquez Sanchez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Jesus Daniel Vazquez Sanchez', 'daniel.vazquez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Hugo Silva
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Hugo Silva', 'hugo.silva@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Alberto Espinoza Portillo
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Alberto Espinoza Portillo', 'alberto.espinoza@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Saul Meza
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Saul Meza', 'Saul.Meza@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Oscar Genaro Palacios
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Oscar Genaro Palacios', 'oscar.palacios.hernandez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Cesar Eduardo Pintor Quiroz
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Cesar Eduardo Pintor Quiroz', 'cesar.pintor@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Juan Colunga
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Juan Colunga', 'juan.colunga@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());

-- Luz Castro Martinez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Luz Castro Martinez', 'luz.elizabeth.castro.martinez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (3, SCOPE_IDENTITY());