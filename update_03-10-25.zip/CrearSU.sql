-- Sarahi Gonzalez
INSERT INTO [dbo].[Users] (FullName, Username, PasswordHash, PasswordSalt, Status, CreatedAt, CreatedBy)
VALUES ('Sarahi Gonzalez', 'Sarahi.Gonzalez@conti.com.mx', 'HCV+z3+u2rq0JUAk0Pdau6lccj5caW5j+k/rYLxmZqQ=', 'd4c68bdb-8a6e-41e1-abd1-91ee8a01d6c4', 0, GETDATE(), 0);
INSERT INTO [dbo].[UserRoles] (RolesId, UserId) VALUES (7, SCOPE_IDENTITY());